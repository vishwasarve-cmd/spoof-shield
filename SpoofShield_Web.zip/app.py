
import os, time, random, base64, csv, hashlib, secrets, hmac, sqlite3, threading
from datetime import datetime
from collections import deque

import cv2
import numpy as np
import torch
import torchvision.models as models
import torchvision.transforms as transforms
from PIL import Image

try:
    import mediapipe as mp
    mp_face_mesh = mp.solutions.face_mesh
except (AttributeError, ImportError):
    import mediapipe.python.solutions.face_mesh as mp_face_mesh

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

os.environ["OPENCV_LOG_LEVEL"] = "OFF"

# ============================================================
# SPOOFSHIELD WEB EDITION
# Original ML logic adapted from the uploaded desktop application.
# Browser handles the webcam; Python handles ML inference.
# ============================================================

DB_FILE = "spoofshield_auth.db"
DATASET_FILE = "authentication_dataset.csv"
PBKDF2_ITERATIONS = 200_000
MAX_FAILED_LOGINS = 5
LOCKOUT_SECONDS = 60

ALL_CHALLENGES = ["TURN_LEFT", "TURN_RIGHT", "BLINK", "SMILE"]
CHALLENGE_NAMES = {
    "TURN_LEFT": "Turn Head LEFT",
    "TURN_RIGHT": "Turn Head RIGHT",
    "BLINK": "Blink Eyes",
    "SMILE": "Smile / Open Mouth",
}

DEEP_WEIGHT = 0.35
TEXTURE_WEIGHT = 0.20
CHROMA_WEIGHT = 0.15
LIVENESS_WEIGHT = 0.30
CHALLENGE_TIMEOUT = 7.0

LEFT_EYE = [362, 385, 387, 263, 373, 380]
RIGHT_EYE = [33, 160, 158, 133, 153, 144]

MODEL_3D_POINTS = np.array([
    (0.0, 0.0, 0.0), (0.0, -330.0, -65.0),
    (-225.0, 170.0, -135.0), (225.0, 170.0, -135.0),
    (-150.0, -150.0, -125.0), (150.0, -150.0, -125.0)
], dtype=np.float64)

app = FastAPI(title="SpoofShield AI")

# -------- Database / authentication --------
def db():
    conn = sqlite3.connect(DB_FILE)
    conn.execute("""CREATE TABLE IF NOT EXISTS users (
        user_id TEXT PRIMARY KEY,
        salt TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        created_at TEXT NOT NULL,
        failed_attempts INTEGER DEFAULT 0,
        locked_until REAL DEFAULT 0
    )""")
    return conn

def hash_password(password, salt_hex):
    return hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"),
        bytes.fromhex(salt_hex), PBKDF2_ITERATIONS
    ).hex()

def register_user_web(user_id, password):
    user_id = user_id.strip()
    if len(user_id) < 3:
        raise HTTPException(400, "User ID must contain at least 3 characters.")
    if len(password) < 8:
        raise HTTPException(400, "Password must contain at least 8 characters.")

    salt = secrets.token_hex(16)
    conn = db()
    try:
        conn.execute(
            "INSERT INTO users VALUES (?, ?, ?, ?, 0, 0)",
            (user_id, salt, hash_password(password, salt), datetime.now().isoformat())
        )
        conn.commit()
        return {"message": "Account created successfully."}
    except sqlite3.IntegrityError:
        raise HTTPException(409, "That User ID already exists.")
    finally:
        conn.close()

def authenticate_user_web(user_id, password):
    conn = db()
    row = conn.execute(
        "SELECT salt,password_hash,failed_attempts,locked_until FROM users WHERE user_id=?",
        (user_id,)
    ).fetchone()

    if not row:
        conn.close()
        return False, "UNKNOWN_USER", 0

    salt, stored_hash, failed, locked_until = row
    now = time.time()

    if locked_until > now:
        conn.close()
        return False, f"LOCKED_{int(locked_until-now)}S", failed

    valid = hmac.compare_digest(hash_password(password, salt), stored_hash)

    if valid:
        conn.execute("UPDATE users SET failed_attempts=0, locked_until=0 WHERE user_id=?", (user_id,))
        conn.commit()
        conn.close()
        return True, "PASSWORD_OK", 0

    failed += 1
    lock = now + LOCKOUT_SECONDS if failed >= MAX_FAILED_LOGINS else 0
    if lock:
        failed = 0

    conn.execute(
        "UPDATE users SET failed_attempts=?, locked_until=? WHERE user_id=?",
        (failed, lock, user_id)
    )
    conn.commit()
    conn.close()
    return False, "PASSWORD_FAILED", failed

def append_login_record(user_id, password_status, liveness_result, ensemble_confidence,
                        deep_score, texture_score, chroma_score, challenge_progress,
                        attempt, latency_ms=0, face_detected=0, stability=0):
    fields = [
        "timestamp", "user_id", "password_status", "liveness_result",
        "ensemble_confidence", "deep_score", "texture_score", "chroma_score",
        "challenge_progress", "attempt", "latency_ms", "face_detected",
        "score_stability"
    ]
    exists = os.path.exists(DATASET_FILE)
    with open(DATASET_FILE, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        if not exists:
            writer.writeheader()
        writer.writerow({
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "user_id": user_id,
            "password_status": password_status,
            "liveness_result": liveness_result,
            "ensemble_confidence": int(ensemble_confidence),
            "deep_score": round(float(deep_score), 4),
            "texture_score": round(float(texture_score), 4),
            "chroma_score": round(float(chroma_score), 4),
            "challenge_progress": round(float(challenge_progress), 4),
            "attempt": attempt,
            "latency_ms": int(latency_ms),
            "face_detected": int(face_detected),
            "score_stability": round(float(stability), 4),
        })

# -------- ML model --------
device = torch.device(
    "mps" if torch.backends.mps.is_available()
    else ("cuda" if torch.cuda.is_available() else "cpu")
)

deep_feature_model = models.mobilenet_v2(
    weights=models.MobileNet_V2_Weights.DEFAULT
)
deep_feature_model.eval().to(device)

deep_preprocess = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225]),
])

face_mesh = mp_face_mesh.FaceMesh(
    max_num_faces=1,
    refine_landmarks=True,
    min_detection_confidence=0.6,
    min_tracking_confidence=0.6
)

inference_lock = threading.Lock()

def calculate_ear(landmarks, eye_indices, img_w, img_h):
    pts = [np.array([landmarks[i].x * img_w, landmarks[i].y * img_h]) for i in eye_indices]
    v1 = np.linalg.norm(pts[1] - pts[5])
    v2 = np.linalg.norm(pts[2] - pts[4])
    h = np.linalg.norm(pts[0] - pts[3])
    return (v1 + v2) / (2.0 * h) if h > 0 else 0.3

def calculate_mar(landmarks, img_w, img_h):
    top = np.array([landmarks[13].x * img_w, landmarks[13].y * img_h])
    bottom = np.array([landmarks[14].x * img_w, landmarks[14].y * img_h])
    left = np.array([landmarks[61].x * img_w, landmarks[61].y * img_h])
    right = np.array([landmarks[291].x * img_w, landmarks[291].y * img_h])
    vertical = np.linalg.norm(top - bottom)
    horizontal = np.linalg.norm(left - right)
    return vertical / horizontal if horizontal > 0 else 0.0

def estimate_3d_pose(landmarks, img_w, img_h):
    image_points = np.array([
        (landmarks[1].x * img_w, landmarks[1].y * img_h),
        (landmarks[152].x * img_w, landmarks[152].y * img_h),
        (landmarks[33].x * img_w, landmarks[33].y * img_h),
        (landmarks[263].x * img_w, landmarks[263].y * img_h),
        (landmarks[61].x * img_w, landmarks[61].y * img_h),
        (landmarks[291].x * img_w, landmarks[291].y * img_h)
    ], dtype=np.float64)

    focal_length = img_w
    center = (img_w / 2, img_h / 2)
    camera_matrix = np.array([
        [focal_length, 0, center[0]],
        [0, focal_length, center[1]],
        [0, 0, 1]
    ], dtype=np.float64)

    success, rot_vec, _ = cv2.solvePnP(
        MODEL_3D_POINTS, image_points, camera_matrix,
        np.zeros((4, 1)), flags=cv2.SOLVEPNP_ITERATIVE
    )
    if not success:
        return 0.0, 0.0, 0.0

    rmat, _ = cv2.Rodrigues(rot_vec)
    angles, _, _, _, _, _ = cv2.RQDecomp3x3(rmat)
    return float(angles[0]), float(angles[1]), float(angles[2])

def analyze_frequency_and_color(roi_bgr):
    if roi_bgr.size == 0:
        return 0.0, 0.0
    gray = cv2.cvtColor(roi_bgr, cv2.COLOR_BGR2GRAY)
    laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
    ycbcr = cv2.cvtColor(roi_bgr, cv2.COLOR_BGR2YCrCb)
    chroma_std = float(np.std(ycbcr[:, :, 1]) + np.std(ycbcr[:, :, 2]))
    return float(laplacian_var), chroma_std

def deep_score(roi_bgr):
    if roi_bgr.size == 0:
        return 0.0
    roi_rgb = cv2.cvtColor(roi_bgr, cv2.COLOR_BGR2RGB)
    tensor = deep_preprocess(Image.fromarray(roi_rgb)).unsqueeze(0).to(device)
    with torch.no_grad():
        features = deep_feature_model.features(tensor)
        variance = torch.var(features).item()
    return min(1.0, max(0.0, (variance - 0.015) / 0.035))

# Per-user web sessions
sessions = {}

def new_session(user_id):
    sessions[user_id] = {
        "challenges": random.sample(ALL_CHALLENGES, 3),
        "current_step": 0,
        "verify_state": 0,
        "challenge_start": time.time(),
        "blink_counter": 0,
        "scores": deque(maxlen=20),
        "attempt": 1,
        "started": time.time(),
        "result_logged": False
    }
    return sessions[user_id]

class Credentials(BaseModel):
    user_id: str
    password: str

class FrameRequest(BaseModel):
    user_id: str
    image: str

@app.post("/api/register")
def api_register(data: Credentials):
    return register_user_web(data.user_id, data.password)

@app.post("/api/login")
def api_login(data: Credentials):
    started = time.time()
    ok, status, _ = authenticate_user_web(data.user_id, data.password)
    latency = (time.time() - started) * 1000

    if not ok:
        append_login_record(data.user_id or "UNKNOWN", status, "NOT_STARTED",
                            0, 0, 0, 0, 0, 1, latency)
        raise HTTPException(401, status.replace("_", " "))

    new_session(data.user_id)
    return {"message": "Login successful", "user_id": data.user_id}

@app.post("/api/reset")
def api_reset(data: dict):
    user_id = data.get("user_id")
    if not user_id:
        raise HTTPException(400, "user_id is required")
    new_session(user_id)
    return {"message": "Scanner reset"}

@app.post("/api/analyze")
def api_analyze(data: FrameRequest):
    if data.user_id not in sessions:
        raise HTTPException(401, "Session not found. Please login again.")

    session = sessions[data.user_id]
    try:
        encoded = data.image.split(",", 1)[1] if "," in data.image else data.image
        image_bytes = base64.b64decode(encoded)
        frame = cv2.imdecode(np.frombuffer(image_bytes, np.uint8), cv2.IMREAD_COLOR)
    except Exception:
        raise HTTPException(400, "Invalid webcam frame")

    if frame is None:
        raise HTTPException(400, "Could not decode frame")

    frame = cv2.flip(frame, 1)
    img_h, img_w, _ = frame.shape
    x1, y1 = int(img_w * 0.25), int(img_h * 0.15)
    x2, y2 = int(img_w * 0.75), int(img_h * 0.85)
    roi = frame[y1:y2, x1:x2]

    with inference_lock:
        raw_score = deep_score(roi)
        session["scores"].append(raw_score)
        smooth_deep = float(
            0.6 * np.median(session["scores"]) +
            0.4 * np.mean(session["scores"])
        )
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = face_mesh.process(rgb)

    avg_ear = mar = pitch = yaw = roll = 0.0
    lap_score, chroma_score = analyze_frequency_and_color(roi)
    face_detected = bool(results.multi_face_landmarks)
    action_completed = False

    if session["verify_state"] == 0 and face_detected:
        landmarks = results.multi_face_landmarks[0].landmark
        avg_ear = (
            calculate_ear(landmarks, LEFT_EYE, img_w, img_h) +
            calculate_ear(landmarks, RIGHT_EYE, img_w, img_h)
        ) / 2
        mar = calculate_mar(landmarks, img_w, img_h)
        pitch, yaw, roll = estimate_3d_pose(landmarks, img_w, img_h)

        target = session["challenges"][session["current_step"]]

        if target == "TURN_LEFT" and yaw > 12.0:
            action_completed = True
        elif target == "TURN_RIGHT" and yaw < -12.0:
            action_completed = True
        elif target == "SMILE" and mar > 0.30:
            action_completed = True
        elif target == "BLINK":
            if avg_ear < 0.20:
                session["blink_counter"] += 1
            else:
                if session["blink_counter"] >= 1:
                    action_completed = True
                session["blink_counter"] = 0

        if action_completed and smooth_deep > 0.25:
            session["current_step"] += 1
            session["challenge_start"] = time.time()
            session["blink_counter"] = 0
            if session["current_step"] >= len(session["challenges"]):
                session["verify_state"] = 1

    if session["verify_state"] == 0:
        elapsed = time.time() - session["challenge_start"]
        if elapsed >= CHALLENGE_TIMEOUT:
            session["verify_state"] = 2
            time_left = 0.0
        else:
            time_left = CHALLENGE_TIMEOUT - elapsed
    else:
        time_left = 0.0

    deep_component = smooth_deep
    texture_component = min(1.0, lap_score / 150.0)
    chroma_component = min(1.0, chroma_score / 20.0)
    liveness_component = session["current_step"] / len(session["challenges"])

    confidence = int(100 * (
        deep_component * DEEP_WEIGHT +
        texture_component * TEXTURE_WEIGHT +
        chroma_component * CHROMA_WEIGHT +
        liveness_component * LIVENESS_WEIGHT
    ))

    contributions = {
        "Deep Features": deep_component * DEEP_WEIGHT,
        "Texture": texture_component * TEXTURE_WEIGHT,
        "Chrominance": chroma_component * CHROMA_WEIGHT,
        "Challenge": liveness_component * LIVENESS_WEIGHT,
    }
    top_reason = max(contributions, key=contributions.get)
    stability = float(np.std(session["scores"])) if len(session["scores"]) > 1 else 0.0

    if session["verify_state"] in (1, 2) and not session["result_logged"]:
        final = "VERIFIED" if session["verify_state"] == 1 else "TIMEOUT"
        append_login_record(
            data.user_id, "PASSWORD_OK", final, confidence,
            deep_component, texture_component, chroma_component,
            liveness_component, session["attempt"],
            (time.time() - session["started"]) * 1000,
            int(face_detected), stability
        )
        session["result_logged"] = True

    if session["verify_state"] == 1:
        title, subtitle, status = "ACCESS GRANTED", "Multi-Model Ensemble Verified", "verified"
        challenge = "Verification Complete"
    elif session["verify_state"] == 2:
        title, subtitle, status = "VERIFICATION TIMEOUT", "Press Reset to restart", "timeout"
        challenge = "Timed out"
    else:
        challenge = CHALLENGE_NAMES[session["challenges"][session["current_step"]]]
        title = f"STEP {session['current_step'] + 1}/3: {challenge}"
        subtitle = f"Time Remaining: {time_left:.1f}s"
        status = "scanning"

    return {
        "status": status,
        "title": title,
        "subtitle": subtitle,
        "challenge": challenge,
        "step": session["current_step"],
        "confidence": confidence,
        "face_detected": face_detected,
        "deep_score": round(smooth_deep * 100, 1),
        "texture_score": round(texture_component * 100, 1),
        "chroma_score": round(chroma_component * 100, 1),
        "yaw": round(yaw, 1),
        "pitch": round(pitch, 1),
        "ear": round(avg_ear, 3),
        "mar": round(mar, 3),
        "stability": round(stability, 4),
        "top_reason": top_reason,
        "contributions": {k: round(v * 100, 1) for k, v in contributions.items()},
        "time_left": round(time_left, 1)
    }

HTML = r"""
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>SpoofShield AI</title>
<style>
*{box-sizing:border-box} body{margin:0;font-family:Inter,Arial,sans-serif;background:#07111f;color:#e8f1ff}
.hidden{display:none!important}.auth{min-height:100vh;display:grid;place-items:center;padding:20px;background:radial-gradient(circle at top,#12345a,#07111f 55%)}
.card{width:min(430px,100%);background:#0d1b2d;border:1px solid #254260;border-radius:22px;padding:32px;box-shadow:0 25px 70px #0008}
.logo{text-align:center;font-size:30px;font-weight:800;color:#63d8ff;letter-spacing:1px}.tag{text-align:center;color:#91a9c2;margin:8px 0 25px}
.tabs{display:flex;gap:8px;margin-bottom:20px}.tabs button{flex:1;padding:12px;border:0;border-radius:10px;background:#142842;color:#b7c9dd;cursor:pointer}.tabs .active{background:#1e7fc1;color:white}
input{width:100%;padding:14px;margin:8px 0;border-radius:10px;border:1px solid #2b4a68;background:#081522;color:white}
.primary{width:100%;padding:14px;border:0;border-radius:10px;background:linear-gradient(90deg,#1493d1,#29c6bb);font-weight:700;color:#03101b;cursor:pointer;margin-top:10px}.msg{min-height:22px;color:#ff9d9d;margin-top:10px}
.dashboard{min-height:100vh;padding:20px}.topbar{display:flex;justify-content:space-between;align-items:center;background:#0d1b2d;padding:16px 22px;border-radius:16px;border:1px solid #203a55}.online{color:#44e69a}
.grid{display:grid;grid-template-columns:minmax(0,1.7fr) minmax(300px,1fr);gap:20px;margin-top:20px}.panel{background:#0d1b2d;border:1px solid #203a55;border-radius:18px;padding:18px}
.video-wrap{position:relative;background:#02070d;border-radius:14px;overflow:hidden;aspect-ratio:16/10}.video-wrap video{width:100%;height:100%;object-fit:cover;transform:scaleX(-1)}
.scanbox{position:absolute;left:25%;top:15%;width:50%;height:70%;border:3px solid #2bd9ff;border-radius:16px;box-shadow:0 0 25px #2bd9ff88;pointer-events:none}
.hud{margin-top:14px;padding:14px;border-radius:12px;background:#091827}.hud h2{margin:0 0 6px;color:#63d8ff;font-size:20px}.muted{color:#8fa5bb}
.metric{padding:12px 0;border-bottom:1px solid #203a55;display:flex;justify-content:space-between}.bar{height:13px;background:#06101c;border-radius:20px;overflow:hidden;margin:10px 0 18px}.bar div{height:100%;width:0;background:linear-gradient(90deg,#1a9de0,#36e4a3);transition:.25s}
.xai{margin-top:18px;padding:15px;background:#091827;border-radius:12px}.contrib{font-size:14px;margin:7px 0}.reset{padding:11px 18px;border:1px solid #2b88ba;background:transparent;color:#63d8ff;border-radius:10px;cursor:pointer}
@media(max-width:850px){.grid{grid-template-columns:1fr}.dashboard{padding:12px}.topbar{gap:10px}.topbar h1{font-size:19px}}
</style>
</head>
<body>

<section id="authPage" class="auth">
  <div class="card">
    <div class="logo">🛡 SPOOFSHIELD AI</div>
    <div class="tag">Multi-Model Face Liveness Verification</div>
    <div class="tabs">
      <button id="loginTab" class="active" onclick="setMode('login')">Login</button>
      <button id="registerTab" onclick="setMode('register')">Create Account</button>
    </div>
    <input id="userId" placeholder="User ID" autocomplete="username">
    <input id="password" type="password" placeholder="Password" autocomplete="current-password">
    <button class="primary" onclick="submitAuth()">Continue</button>
    <div id="authMsg" class="msg"></div>
  </div>
</section>

<section id="dashboard" class="dashboard hidden">
  <div class="topbar">
    <div><h1 style="margin:0;color:#63d8ff">🛡 SPOOFSHIELD AI</h1><span class="muted">Professional Multi-Model Engine</span></div>
    <div><span class="online">● SYSTEM ONLINE</span> &nbsp; <button class="reset" onclick="resetScanner()">Reset Scanner</button></div>
  </div>

  <div class="grid">
    <div class="panel">
      <div class="video-wrap">
        <video id="video" autoplay playsinline muted></video>
        <div class="scanbox"></div>
      </div>
      <div class="hud">
        <h2 id="title">Starting scanner...</h2>
        <div id="subtitle" class="muted">Allow webcam access</div>
      </div>
    </div>

    <div class="panel">
      <h3 style="margin-top:0">MULTI-MODEL DASHBOARD</h3>
      <div class="metric"><span>User</span><b id="userDisplay">-</b></div>
      <div class="metric"><span>Face Detected</span><b id="face">-</b></div>
      <div class="metric"><span>Deep Feature Score</span><b id="deep">-</b></div>
      <div class="metric"><span>Texture Score</span><b id="texture">-</b></div>
      <div class="metric"><span>Chrominance Score</span><b id="chroma">-</b></div>
      <div class="metric"><span>Yaw / Pitch</span><b id="pose">-</b></div>
      <div class="metric"><span>EAR / MAR</span><b id="bio">-</b></div>

      <div style="margin-top:18px">ENSEMBLE LIVENESS: <b id="confidence">0%</b></div>
      <div class="bar"><div id="confidenceBar"></div></div>

      <div class="xai">
        <b>🧠 XAI DECISION EXPLANATION</b>
        <div class="muted" id="reason" style="margin:8px 0">Waiting for ML inference...</div>
        <div id="contributions"></div>
      </div>
    </div>
  </div>
</section>

<script>
let mode='login', user='', stream=null, timer=null, busy=false;
const $=id=>document.getElementById(id);

function setMode(m){
  mode=m;
  $('loginTab').classList.toggle('active',m==='login');
  $('registerTab').classList.toggle('active',m==='register');
  $('authMsg').textContent='';
}

async function submitAuth(){
  const user_id=$('userId').value.trim(), password=$('password').value;
  if(!user_id || !password){$('authMsg').textContent='Enter User ID and password.';return}
  const endpoint=mode==='login'?'/api/login':'/api/register';
  try{
    const r=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({user_id,password})});
    const d=await r.json();
    if(!r.ok) throw new Error(d.detail||'Request failed');
    if(mode==='register'){ $('authMsg').style.color='#44e69a';$('authMsg').textContent='Account created. Please login.';setMode('login');return; }
    user=user_id;$('authPage').classList.add('hidden');$('dashboard').classList.remove('hidden');
    $('userDisplay').textContent=user;
    await startCamera();
  }catch(e){$('authMsg').style.color='#ff9d9d';$('authMsg').textContent=e.message}
}

async function startCamera(){
  try{
    stream=await navigator.mediaDevices.getUserMedia({video:{width:{ideal:640},height:{ideal:480}},audio:false});
    $('video').srcObject=stream;
    $('video').onloadedmetadata=()=>{timer=setInterval(analyze,900)};
  }catch(e){$('subtitle').textContent='Camera error: '+e.message}
}

async function analyze(){
  if(busy || !$('video').videoWidth) return;
  busy=true;
  try{
    const c=document.createElement('canvas'); c.width=$('video').videoWidth;c.height=$('video').videoHeight;
    c.getContext('2d').drawImage($('video'),0,0);
    const image=c.toDataURL('image/jpeg',0.75);
    const r=await fetch('/api/analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({user_id:user,image})});
    const d=await r.json(); if(!r.ok) throw new Error(d.detail||'Analysis failed');
    updateUI(d);
  }catch(e){$('subtitle').textContent=e.message}
  busy=false;
}

function updateUI(d){
  $('title').textContent=d.title;$('subtitle').textContent=d.subtitle;
  $('face').textContent=d.face_detected?'YES':'NO';
  $('deep').textContent=d.deep_score+'%';$('texture').textContent=d.texture_score+'%';$('chroma').textContent=d.chroma_score+'%';
  $('pose').textContent=d.yaw+'° / '+d.pitch+'°';$('bio').textContent=d.ear+' / '+d.mar;
  $('confidence').textContent=d.confidence+'%';$('confidenceBar').style.width=d.confidence+'%';
  $('reason').textContent='Top evidence: '+d.top_reason;
  $('contributions').innerHTML=Object.entries(d.contributions).map(([k,v])=>`<div class="contrib">${k}: <b>${v}%</b></div>`).join('');
}

async function resetScanner(){
  await fetch('/api/reset',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({user_id:user})});
  $('title').textContent='Scanner reset';
}
</script>
</body>
</html>
"""

@app.get("/", response_class=HTMLResponse)
def home():
    return HTML
